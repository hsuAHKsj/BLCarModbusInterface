# REUSE Software

This directory contains supporting files to make the project compliant with the REUSE specification.

The root `Makefile` contains a target `reuse` that updates copyright headers and checks for compliance.

See <http://reuse.software> for more information.
